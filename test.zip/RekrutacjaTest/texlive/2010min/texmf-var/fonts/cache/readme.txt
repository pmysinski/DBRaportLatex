Do not delete this directory and keep it writable!
