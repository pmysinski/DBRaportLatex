-- original texmfcnf.lua: TEXMFCACHE setting for luatools --generate.
-- Public domain.
--
-- If you modify this original file, YOUR CHANGES WILL BE LOST when it
-- is updated.  Instead, put your version in ../../texmfcnf.lua.  That
-- is, if this file is installed in
-- /some/path/to/texlive/2010/texmf/web2c/texmfcnf.lua, 
-- put your custom settings in /some/path/to/texlive/2010/texmfcnf.lua.
--
-- This file is intended only for use by ConTeXt.
--
return {
  TEXMFCACHE = '~/.texlive2010/texmf-var'
}

